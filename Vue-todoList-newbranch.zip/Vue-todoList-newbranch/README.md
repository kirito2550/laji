# Vue-todoList
EventBusを用いて、親子関係になくても情報の受け渡しができるようにする
